Arquivo zip gerado em: 28/11/2022 05:05:33 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 06 - Árvore AVL de jogos - PESO *3